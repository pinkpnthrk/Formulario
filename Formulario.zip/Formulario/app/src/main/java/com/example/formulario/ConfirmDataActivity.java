package com.example.formulario;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConfirmDataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_data);
    }
}
